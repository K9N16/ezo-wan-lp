エゾわん！ ロゴ素材

使い方の決まりは、次のページにまとめています。お使いになる前に、必ずご覧ください。
https://pet.rai-group.net/brand/

■ 入っているもの
・ezowan-logo-horizontal-*  横長(ふだんはこちら)
・ezowan-logo-vertical-*    縦型
・ezowan-logo-mark-*        マークだけ(小さい場所に)
・ezowan-app-icon-1024.png  アプリアイコン
  色の版: color=カラー / white=白抜き / black=黒1色
  形式: SVG(印刷・拡大に) / PNG(背景は透明。Web・資料に)

■ 守っていただきたいこと
・色や形を変えない(伸ばす・傾ける・影をつける・文字を打ち直す、もしないでください)
・まわりに、丸の幅の4分の1以上の余白を空ける
・小さくしすぎない(横長は幅30mm・120px以上)

■ ブランドの色
・エゾわんオレンジ  #CD641E  RGB 205,100,30  CMYK C0 M70 Y95 K10(目安)
・ロゴの黒          #1F1D1B  RGB 31,29,27    K100(目安)

■ お問い合わせ
ezo-wan@rai-group.net(RAI GROUP)
